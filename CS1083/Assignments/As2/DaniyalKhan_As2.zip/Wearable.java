public interface Wearable {
    public String getColour();
    public String getSize();
    public boolean inFashion(String season);
}