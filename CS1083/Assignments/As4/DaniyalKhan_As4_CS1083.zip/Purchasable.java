public interface Purchasable {
    public String getTitle();
    public double getSellingPrice();
} 