public class PositiveInterestException extends Exception {

    public PositiveInterestException (String msg) {
        super(msg);
    }
}