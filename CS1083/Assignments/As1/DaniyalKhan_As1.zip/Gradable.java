public interface Gradable {

    public double calculateGPA();
    
    public String listCourses();
}