public class NegativeException extends Exception{
    
    public NegativeException(String message) {
        super(message);
    }
}
