/**
 This class represents a triangle shape using 3 points.
 @author Natalie Webber
*/
public class Triangle {

   private CartesianPoint pointA;
   private CartesianPoint pointB;
   private CartesianPoint pointC;
  
   public Triangle (double x1, double y1,
                    double x2, double y2,
                    double x3, double y3) {
      pointA = new CartesianPoint (x1, y1);
      pointB = new CartesianPoint (x2, y2);
      pointC = new CartesianPoint (x3, y3);
   }
  
   public Triangle (CartesianPoint p1,
                    CartesianPoint p2,
                    CartesianPoint p3) {
      pointA = p1;
      pointB = p2;
      pointC = p3;
   }
  
 
}
